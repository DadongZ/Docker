#include "GlobalVariables.h"
Stats g_statsAll;//global mapping statistics
ThreadControl g_threadChunks;

