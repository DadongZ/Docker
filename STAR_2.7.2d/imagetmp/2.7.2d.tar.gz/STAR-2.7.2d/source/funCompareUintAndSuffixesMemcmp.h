#ifndef CODE_funCompareUintAndSuffixesMemcmp
#define CODE_funCompareUintAndSuffixesMemcmp

#include <stdint.h>

extern char* g_funCompareUintAndSuffixesMemcmp_G;
extern uint64_t g_funCompareUintAndSuffixesMemcmp_L;
int funCompareUintAndSuffixesMemcmp ( const void *a, const void *b);

#endif